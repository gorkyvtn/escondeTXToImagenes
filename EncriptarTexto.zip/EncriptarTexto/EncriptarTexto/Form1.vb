﻿Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Image
Imports System.Math

Public Class Principal
    Dim matriz1(200, 200, 2) As Integer 'almacena los valores de los pixeles r g b
    'Dim valorpixel(6, 6, 2) As TextBox  ' matriz de cuadros de texto para mostrar los valores de la imagen
    'Dim valor1, x, y, r, g, b As Integer

    Dim miimagen As Bitmap   'variable global
    Private Sub btvCarga_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btvCarga.Click
        Dim imagen As Bitmap 'define el objeto bitmap
        imagen = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height) 'define ancho y alto del pic
        With Me.OpenFileDialog1
            .Filter = "All Image Formats (*.bmp;*.jpg;*.jpeg;*.gif;*.tif)|" & "*.bmp;*.jpg;*.jpeg;*.gif;*.tif|Bitmaps (*.bmp)|*.bmp|" & "GIFs (*.gif)|*.gif|JPEGs (*.jpg)|*.jpg;*.jpeg|TIFs (*.tif)|*.tif"
            .FilterIndex = 1
        End With
        If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            imagen = FromFile(OpenFileDialog1.FileName)
        End If
        ReDim matriz1(imagen.Height - 1, imagen.Width - 1, 2)
        'imagen.PixelFormat.ToString()
        bitmap_to_mRGB(imagen, matriz1) 'usa bitmapdata

        Me.PictureBox1.Width = imagen.Width      'cambia el ancho y el alto del picturebox
        Me.PictureBox1.Height = imagen.Height   'para mostrar la imagen
        Me.PictureBox1.Image = imagen                  'coloca la imagen en el picture box
        'miimagen = New Bitmap(Me.PictureBox1.Image)
    End Sub

    Private Sub btnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGuardar.Click
        Try
            Dim saveImage As New SaveFileDialog 'Este es el SaveFileDialog
            Dim ruta As String = "" 'Para tener la ruta de la imagen

            saveImage.Title = "Guardar imagen como..." 'Título de la ventana
            saveImage.Filter = "Imagen BMP (*.bmp)|*.bmp|Imagen JPG (*.jpg)|*.jpg" 'Los formatos en que se guardará la imagen
            If saveImage.ShowDialog() = Windows.Forms.DialogResult.OK Then
                'Recuperar la ruta de la imagen si no está vacía
                If Not String.IsNullOrEmpty(saveImage.FileName) Then ruta = saveImage.FileName

                Dim myImg As Image 'Objeto Image para guardar la imagen del Picture 
                Dim extension As String = ruta.Substring(ruta.Length - 3, 3) 'Recuperar los ultimos 3 caracteres de la extensión

                myImg = PictureBox2.Image 'Guardar la imagen del PictureBox en el objeto Image

                Select Case extension
                    Case "bmp"
                        myImg.Save(ruta, Imaging.ImageFormat.Bmp) 'Guardar en formato BMP
                    Case "jpg"
                        myImg.Save(ruta, Imaging.ImageFormat.Jpeg) 'Guardar en formato JPG
                End Select
            End If
        Catch ex As Exception
            MsgBox("Ocurrió el siguiente error: " & ex.Message, MsgBoxStyle.Critical, "Error!")
        End Try
    End Sub
    Private Sub btnEncripta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEncripta.Click
        Dim i1, i2 As Bitmap
        i1 = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height, Imaging.PixelFormat.Format24bppRgb)
        i2 = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height, Imaging.PixelFormat.Format24bppRgb)

        i1 = Me.PictureBox1.Image

        Dim capa As String
        capa = InputBox("Ingrese 'r', 'g', 'b'")

        Encriptar(i1, i2, Me.rtbDatos.Text, capa)

        Me.PictureBox2.Image = i2
    End Sub


End Class
