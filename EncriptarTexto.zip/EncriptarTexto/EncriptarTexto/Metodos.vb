﻿Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Image
Imports System.Math
Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices
Module Metodos
    Sub bitmap_to_matrizrgb(ByRef matr(,,) As Integer, _
                        ByRef mibitmap As Bitmap)
        Dim i, j, nf, nc As Integer
        ' i, j          indices de la matriz (i filas, j columnas)
        ' nf nc         numero de filas, numro de columans de la matriz
        Dim micolor As Color    'deffine objeto color
        nc = UBound(matr, 2)    'almacena en nc el maximo valor de columnas de la matriz
        nf = UBound(matr, 1)    'almacena el nf el maximo valor de las filas de la matriz
        For i = 0 To nf
            For j = 0 To nc
                micolor = mibitmap.GetPixel(j, i)  '(formato x=j,y=i)'
                'mibitmap.SetPixel(j, i, Color)  '(formato x=j,y=i)'
                'para sencillo es facil pero para cosas complejas es muy lento
                matr(i, j, 0) = micolor.R
                matr(i, j, 1) = micolor.G
                matr(i, j, 2) = micolor.B
            Next
        Next
    End Sub

    Sub bitmap_to_mRGB(ByRef imagen As Bitmap, _
                   ByRef mat(,,) As Integer)
        'usa bitmapdata

        Dim datos As BitmapData  'inf de valores de pixeles
        Dim width As Integer = imagen.Width
        Dim height As Integer = imagen.Height
        Dim index As Integer 'indice para barrer todos los pix de la imagen
        ' Lock the bitmap's bits, get a BitmapData object
        Dim rect As New Rectangle(0, 0, width, height) 'define un rectangulo
        '                                               del tamaño de la imagen
        datos = imagen.LockBits(rect, _
                    Drawing.Imaging.ImageLockMode.ReadWrite, _
                     imagen.PixelFormat)
        'paso todos los pixeles a datos
        ' Get the address of its first scan line
        Dim ptr As IntPtr = datos.Scan0  'dirección de datos

        ' Prepare an array that will receive all the pixels
        Dim bytes As Integer = datos.Stride * height 'num total de pix del bitmapdata
        Dim pixels(bytes) As Byte

        ' Copy the pixels into the array
        Marshal.Copy(ptr, pixels, 0, bytes)

        ' Now we have the data in a buffer, we can process it much more quickly than GetPixel/SetPixel
        ' The buffer elements now contain RGB data thus:
        ' R1 G1 B1 R2 G2 B2 R3 G3 B3...Rn Gn Bn
        ' so we traverse the array in steps of 3.  (Note: this is because it's 3 bytes per pixel.  Change this for other formats)
        Dim i, j As Integer

        For i = 0 To height - 1
            For j = 0 To width - 1
                index = (i * datos.Stride) + (j * 3) ' 3 bytes per pixel
                mat(i, j, 0) = pixels(index)
                mat(i, j, 1) = pixels(index + 1)
                mat(i, j, 2) = pixels(index + 2)
            Next
        Next
        imagen.UnlockBits(datos)
    End Sub

    Sub matrizreal_to_bitmap(ByVal mr(,) As Double, _
                             ByRef imagen As Bitmap)
        'realiza normalizacion de 0 a 255
        Dim i, j, nf, nc, ng As Integer
        'numero de filas y columnas de la matriz para los indices
        nf = UBound(mr, 1)
        nc = UBound(mr, 2)
        'obtencion de valmin y valmax de mr
        Dim valmin, valmax As Double
        valmin = 5.0E+300 : valmax = -5.0E+300
        For i = 0 To nf
            For j = 0 To nc
                If valmin > mr(i, j) Then valmin = mr(i, j)
                If valmax < mr(i, j) Then valmax = mr(i, j)
            Next
        Next
        'normalizar a 255
        valmax = valmax - valmin
        For i = 0 To nf
            For j = 0 To nc
                mr(i, j) = mr(i, j) - valmin
                mr(i, j) = mr(i, j) / valmax * 255
            Next
        Next
        ' uso de bitmapdata
        ' define los datos
        Dim datos As BitmapData
        Dim width As Integer = imagen.Width
        Dim height As Integer = imagen.Height
        Dim index As Integer
        ' Lock the bitmap's bits, get a BitmapData object
        Dim rect As New Rectangle(0, 0, width, height)
        datos = imagen.LockBits(rect, _
                                Drawing.Imaging.ImageLockMode.ReadWrite, _
                                imagen.PixelFormat)
        'MessageBox.Show(imagen.PixelFormat.ToString)


        ' Get the address of its first scan line
        Dim ptr As IntPtr = datos.Scan0

        ' Prepare an array that will receive all the pixels
        Dim bytes As Integer = datos.Stride * height
        Dim pixels(bytes) As Byte



        Dim nbpp As Integer = 3

        'If formato = "32bpp" Then nbpp = 4

        For i = 0 To nf
            For j = 0 To nc
                index = (i * datos.Stride) + (j * nbpp) ' num bytes per pixel
                ng = Convert.ToInt16(mr(i, j))


                'para 24 bits
                pixels(index) = ng 'r
                pixels(index + 1) = ng 'g
                pixels(index + 2) = ng 'b

            Next
        Next
        Marshal.Copy(pixels, 0, ptr, bytes)
        imagen.UnlockBits(datos)
    End Sub

    Sub matrizreal_to_bitmap(ByVal mr(,,) As Double, ByRef imagen As Bitmap)
        'realiza normalizacion de 0 a 255
        Dim i, j, k, nf, nc, ng As Integer
        'numero de filas y columnas de la matriz para los indices
        nf = UBound(mr, 1)
        nc = UBound(mr, 2)
        'obtencion de valmin y valmax de mr
        Dim valmin, valmax As Double

        For k = 0 To 2  'bucle de cada plano
            valmin = 5.0E+300 : valmax = -5.0E+300
            For i = 0 To nf
                For j = 0 To nc
                    If valmin > mr(i, j, k) Then valmin = mr(i, j, k)
                    If valmax < mr(i, j, k) Then valmax = mr(i, j, k)
                Next
            Next
            'normalizar a 255
            valmax = valmax - valmin
            For i = 0 To nf
                For j = 0 To nc
                    mr(i, j, k) = mr(i, j, k) - valmin
                    mr(i, j, k) = mr(i, j, k) / valmax * 255
                Next
            Next
        Next k

        ' uso de bitmapdata
        ' define los datos
        Dim datos As BitmapData
        Dim width As Integer = imagen.Width
        Dim height As Integer = imagen.Height
        Dim index As Integer
        ' Lock the bitmap's bits, get a BitmapData object
        Dim rect As New Rectangle(0, 0, width, height)
        datos = imagen.LockBits(rect, _
                                Drawing.Imaging.ImageLockMode.ReadWrite, _
                                imagen.PixelFormat)
        'MessageBox.Show(imagen.PixelFormat.ToString)
        ' Get the address of its first scan line
        Dim ptr As IntPtr = datos.Scan0
        ' Prepare an array that will receive all the pixels
        Dim bytes As Integer = datos.Stride * height
        Dim pixels(bytes) As Byte



        Dim nbpp As Integer = 3

        'If formato = "32bpp" Then nbpp = 4
        For k = 0 To 2
            For i = 0 To nf
                For j = 0 To nc
                    index = (i * datos.Stride) + (j * nbpp) ' num bytes per pixel
                    ng = Convert.ToInt16(mr(i, j, k))
                    'para 24 bits, k varia de 0 a2
                    pixels(index + k) = ng 'r
                Next
            Next
        Next k
        Marshal.Copy(pixels, 0, ptr, bytes)
        imagen.UnlockBits(datos)
    End Sub

    Sub bitmap_to_m(ByRef imagen As Bitmap, ByRef mat(,) As Integer)
        'usa bitmapdata
        'pasa el plano r de la imagen a la matriz


        Dim datos As BitmapData  'inf de valores de pixeles
        Dim width As Integer = imagen.Width
        Dim height As Integer = imagen.Height
        Dim index As Integer 'indice para barrer todos los pix de la imagen
        ' Lock the bitmap's bits, get a BitmapData object
        Dim rect As New Rectangle(0, 0, width, height) 'define un rectangulo
        '                                               del tamaño de la imagen
        datos = imagen.LockBits(rect, _
                                Drawing.Imaging.ImageLockMode.ReadWrite, _
                                imagen.PixelFormat)
        'paso todos los pixeles a datos
        ' Get the address of its first scan line
        Dim ptr As IntPtr = datos.Scan0  'dirección de datos

        ' Prepare an array that will receive all the pixels
        Dim bytes As Integer = datos.Stride * height 'num total de pix del bitmapdata
        Dim pixels(bytes) As Byte

        ' Copy the pixels into the array
        Marshal.Copy(ptr, pixels, 0, bytes)

        ' Now we have the data in a buffer, we can process it much more quickly than GetPixel/SetPixel
        ' The buffer elements now contain RGB data thus:
        ' R1 G1 B1 R2 G2 B2 R3 G3 B3...Rn Gn Bn
        ' so we traverse the array in steps of 3.  (Note: this is because it's 3 bytes per pixel.  Change this for other formats)
        Dim i, j As Integer

        For i = 0 To height - 1
            For j = 0 To width - 1
                index = (i * datos.Stride) + (j * 3) ' 3 bytes per pixel
                'solo un plano
                mat(i, j) = pixels(index)
            Next
        Next
        imagen.UnlockBits(datos)
    End Sub

    Sub Encriptar(ByRef i1 As Bitmap, ByRef i2 As Bitmap, ByRef st As String, ByRef capa As String)
        ' Dim i, j As  String
        Dim alto, ancho As Integer
        alto = i1.Height
        ancho = i1.Width
        Dim M1(alto - 1, ancho - 1, 2) As Integer 'xq la funcion ascqi retorna dobles
        Dim M2(alto - 1, ancho - 1, 2) As Double
        'PASAR la imagen A MATRIZ de enteros
        bitmap_to_mRGB(i1, M1)
        'senal q si hay un mensaje oculto
        M1(0, 0, 0) = 0
        M1(0, 0, 1) = 0
        M1(0, 0, 2) = 7 'bandera de inicio
        Dim cont, unosolo As Integer
        cont = 0 : unosolo = 0
        '-------------------------------------------------------------------------
        If capa = "r" Then
            M1(0, 1, 0) = 0
            M1(0, 1, 1) = 255
            M1(0, 1, 2) = 255
        End If
        If capa = "g" Then
            M1(0, 1, 0) = 255
            M1(0, 1, 1) = 0
            M1(0, 1, 2) = 255
        End If
        If capa = "b" Then
            M1(0, 1, 0) = 255
            M1(0, 1, 1) = 255
            M1(0, 1, 2) = 0
        End If
        For i = 2 To alto - 1
            For j = 2 To ancho - 1
                If cont < st.Length - 1 Then
                    If capa = "r" Then
                        M1(i, j, 0) = AscW(st(cont))
                    End If
                    If capa = "g" Then
                        M1(i, j, 1) = AscW(st(cont))
                    End If
                    If capa = "b" Then
                        M1(i, j, 2) = AscW(st(cont))
                    End If
                    cont += 1
                Else
                    If unosolo = 0 Then 'cuando termina de pasar el string al final pone un 007
                        unosolo += 1
                        M1(i, j, 0) = 0
                        M1(i, j, 1) = 0
                        M1(i, j, 2) = 7
                        i = alto
                        j = ancho 'finaliza los for y deja intacta el resto de la matriz q contiene la imagen
                    End If
                End If
            Next
        Next
        'PROCESO DE M1
        For i = 0 To alto - 1
            For j = 0 To ancho - 1
                'implantar el ma matriz vacia la imagen
                M2(i, j, 0) = M1(i, j, 0)
                M2(i, j, 1) = M1(i, j, 1)
                M2(i, j, 2) = M1(i, j, 2)
            Next j
        Next i
        matrizreal_to_bitmap(M2, i2)
    End Sub

End Module
