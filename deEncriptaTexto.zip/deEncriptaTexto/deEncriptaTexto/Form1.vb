﻿Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Image
Imports System.Math
Public Class Form1
    Dim matriz1(200, 200, 2) As Integer 'almacena los valores de los pixeles r g b
    Dim miimagen As Bitmap   'variable global

    Private Sub btvCarga_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btvCarga.Click
        Dim imagen As Bitmap 'define el objeto bitmap
        imagen = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height) 'define ancho y alto del pic
        With Me.OpenFileDialog1
            .Filter = "All Image Formats (*.bmp;*.jpg;*.jpeg;*.gif;*.tif)|" & "*.bmp;*.jpg;*.jpeg;*.gif;*.tif|Bitmaps (*.bmp)|*.bmp|" & "GIFs (*.gif)|*.gif|JPEGs (*.jpg)|*.jpg;*.jpeg|TIFs (*.tif)|*.tif"
            .FilterIndex = 1
        End With
        If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            imagen = FromFile(OpenFileDialog1.FileName)
        End If
        ReDim matriz1(imagen.Height - 1, imagen.Width - 1, 2)
        imagen.PixelFormat.ToString()
        bitmap_to_mRGB(imagen, matriz1) 'usa bitmapdata

        Me.PictureBox1.Width = imagen.Width      'cambia el ancho y el alto del picturebox
        Me.PictureBox1.Height = imagen.Height   'para mostrar la imagen
        Me.PictureBox1.Image = imagen                  'coloca la imagen en el picture box
        miimagen = New Bitmap(Me.PictureBox1.Image)
    End Sub

    Private Sub btnDesEncripta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDesEncripta.Click
        Dim i1 As Bitmap
        i1 = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height, Imaging.PixelFormat.Format24bppRgb)

        Dim datos As String
        'capa = ""
        'capa = InputBox("Ingrese la capa donde esta la informacion 'r', 'g', 'b'")
        datos = ""

        desEncriptar(Me.PictureBox1.Image, datos)
        Me.rtbDatos.Text = datos
       
    End Sub
End Class
