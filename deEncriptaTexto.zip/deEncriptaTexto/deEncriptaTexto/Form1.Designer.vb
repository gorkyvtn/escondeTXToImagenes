﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDesEncripta = New System.Windows.Forms.Button()
        Me.rtbDatos = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btvCarga = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDesEncripta
        '
        Me.btnDesEncripta.Location = New System.Drawing.Point(158, 526)
        Me.btnDesEncripta.Name = "btnDesEncripta"
        Me.btnDesEncripta.Size = New System.Drawing.Size(87, 23)
        Me.btnDesEncripta.TabIndex = 11
        Me.btnDesEncripta.Text = "Des-Encripta"
        Me.btnDesEncripta.UseVisualStyleBackColor = True
        '
        'rtbDatos
        '
        Me.rtbDatos.Location = New System.Drawing.Point(517, 44)
        Me.rtbDatos.Name = "rtbDatos"
        Me.rtbDatos.Size = New System.Drawing.Size(264, 459)
        Me.rtbDatos.TabIndex = 10
        Me.rtbDatos.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(514, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Texto que la imagen contiene"
        '
        'btvCarga
        '
        Me.btvCarga.Location = New System.Drawing.Point(36, 526)
        Me.btvCarga.Name = "btvCarga"
        Me.btvCarga.Size = New System.Drawing.Size(75, 23)
        Me.btvCarga.TabIndex = 8
        Me.btvCarga.Tag = " Dim matriz1(200, 200, 2) As Integer 'almacena los valores de los pixeles r g b"
        Me.btvCarga.Text = "Carga"
        Me.btvCarga.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(438, 491)
        Me.Panel1.TabIndex = 7
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(792, 573)
        Me.Controls.Add(Me.btnDesEncripta)
        Me.Controls.Add(Me.rtbDatos)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btvCarga)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = ":) des_EncritaTexto"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDesEncripta As System.Windows.Forms.Button
    Friend WithEvents rtbDatos As System.Windows.Forms.RichTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btvCarga As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog

End Class
